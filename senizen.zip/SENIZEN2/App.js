import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';

import OnboardingScreen from './screens/OnboardingScreen';
import DashboardScreen from './screens/DashboardScreen';
import SignupScreen from './screens/SignupScreen';
import DetailScreen from './screens/DetailScreen';
import HomeScreen from './screens/HomeScreen';
const AppStack = createStackNavigator();

const App = () => {
  return(
      <NavigationContainer>
        <AppStack.Navigator
          headerMode="none"
        >
        
          <AppStack.Screen name="Onboarding" component = {OnboardingScreen}/>
          <AppStack.Screen name="Dashboard" component = {DashboardScreen}/>
          <AppStack.Screen name="Signup" component = {SignupScreen}/>
          <AppStack.Screen name="Detail" component = {DetailScreen}/>
          <AppStack.Screen name='Home' component = {HomeScreen}/>

        </AppStack.Navigator>
      </NavigationContainer>
  );
}

export default App;