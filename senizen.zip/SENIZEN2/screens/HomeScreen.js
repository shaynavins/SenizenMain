import { StylesProvider } from '@material-ui/styles';
import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  Image,
  ScrollView,
  ImageBackground,
  SafeAreaView,
} from 'react-native';

export default function Home() {
    return(
        <View style={styles.Pcontainer}>
        <SafeAreaView>
            <View style={styles.headerWrapper}>
                <Image 
                source={require('/Users/preethipolepalli/senizen/assets/cherry-645.png')} style={styles.profileImage}
                />
            </View>
        </SafeAreaView>

        </View>
    );
}

const styles = StyleSheet.create({
    Pcontainer: {
      flex: 1,
    },
    headerWrapper: {
      flexDirection: 'row',
      justifyContent: 'space-between',
      paddingHorizontal: 20,
      paddingTop: 20,
      alignItems: 'center',
    },
    profileImage: {
      width: 40,
      height: 40,
      borderRadius: 40,
    }
});