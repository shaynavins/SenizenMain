import { grey } from '@material-ui/core/colors';
import { PlayCircleFilledWhite } from '@material-ui/icons';
import * as React from 'react';
import { Button, Text, View, StyleSheet, Image, Platform, TouchableOpacity } from 'react-native';

export default function Detail(){
    
return(
    
<View style={styles.container}>
       

       <View style={styles.RectangleShapeView} >
       
       </View>
       
       

       <Text style={styles.text}>Your Profile</Text>

       <Image
        style={styles.tinyLogo}
        source={require('/Users/preethipolepalli/senizen/assets/cherry-645.png')}/>
       <Text style={styles.text2}>Number</Text>
       <Text style={styles.line}>______________________________________________</Text>
        <Image
        style={styles.tinyLogo2}
        source={require('/Users/preethipolepalli/senizen/assets/bermuda-message.png')}/>
            <Text style={styles.text3}>EmailID</Text>
            <Text style={styles.line}>______________________________________________</Text>

            
     </View>
     
     
)};


 
const styles = StyleSheet.create({
 
    container: {
   
      flex: 1,
      justifyContent: 'center',
      alignItems: 'center',
      backgroundColor: '#F5FCFF',
    },

    text: {
        marginTop: 20,  
        marginLeft: -200,  
        fontWeight: "bold", 
        fontSize: 30,
    },
    text2: {
        marginTop: -100,  
        marginLeft: -100,  
    },
    text3: {
        marginTop: -60,  
        marginLeft: -100,  
    },
    line: {
        marginTop: 50,
        color: "lightgrey", 
    },
   
    RectangleShapeView: {
   
    marginTop: -500,

    width: 400,
    height: 400,
    backgroundColor: '#FFC107', 
    borderRadius:20,
   
    }, 
    tinyLogo: {
        marginTop: 20,
        marginBottom: 40,

        marginLeft: -300,
    
        width: 50,
        height: 90,
      },
      tinyLogo2: {
        marginTop: 20,
    
        marginLeft: -290,
    
        width: 90,
        height: 100,
      },
      tinyLogo4: {
         marginLeft:-400,
         marginTop:250,
         width: 90,
         height: 100,

      },
   
  });

