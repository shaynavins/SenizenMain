import React from 'react';
import {View, Text, Button, StyleSheet, Image} from 'react-native';
import Onboarding from "react-native-onboarding-swiper";

const img1 = require('/Users/preethipolepalli/senizen/assets/snc.png');
const img2 = require('/Users/preethipolepalli/senizen/assets/rename.png');

const OnboardingScreen = ({navigation}) => {
    return(
        <Onboarding
            onSkip={() => navigation.navigate("Signup")}
            onDone={() => navigation.navigate("Signup")}

            pages={[
                {
                    backgroundColor:'#fff',
                    title: "Welcome!",
                    subtitle: "Welcome to SeniZen!!",
                    image: <Image source={img1} resizeMode="contain" style={{ width: 350, height: 350 }} />,
                },
                {
                    backgroundColor:'#fff',
                    title: "Settle in!",
                    subtitle: "Let's establish a connection like never before!",
                    image: <Image source={img2} resizeMode="contain" style={{ width: 400, height: 300 }} />,
                    
                },
            ]}
        />
    );
};

export default OnboardingScreen;

const styles = StyleSheet.create({
    container: {
        flex: 1,
        alignItems: 'center',
        justifyContent: 'center'
    },
});