import React, { useState, useEffect } from 'react';
import { Button, Text, View, StyleSheet, Image, ActivityIndicator, Platform, ImageBackground, SafeAreaView, FlatList, Dimensions } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { createStackNavigator } from '@react-navigation/stack';
import { ScrollView, TouchableOpacity } from 'react-native-gesture-handler';
import Swiper from 'react-native-swiper'
import colors from '../assets/colors/colors';
import {
  GoogleSignin,
  GoogleSigninButton,
  statusCodes,
} from 'react-native-google-signin';
import { WEB_CLIENT_ID } from '../utils/keys.js';
import { BorderLeft } from '@material-ui/icons';


function Feed({ navigation, routhe }) {
  const [userInfo, setUserInfo] = useState(null);
  const [gettingLoginStatus, setGettingLoginStatus] = useState(true);

  useEffect(() => {
    // Initial configuration
    GoogleSignin.configure({
      // Mandatory method to call before calling signIn()
      webClientId: WEB_CLIENT_ID,
      offlineAccess: false

    });
    // Check if user is already signed in
    _isSignedIn();
  }, []);

  const _isSignedIn = async () => {
    const isSignedIn = await GoogleSignin.isSignedIn();
    if (isSignedIn) {
      // Set User Info if user is already signed in
      _getCurrentUserInfo();
    } else {
      console.log('Please Login');
    }
    setGettingLoginStatus(false);
  };

  const _getCurrentUserInfo = async () => {
    try {
      let info = await GoogleSignin.signInSilently();
      console.log('User Info --> ', info);
      setUserInfo(info);
    } catch (error) {
      if (error.code === statusCodes.SIGN_IN_REQUIRED) {
        alert('User has not signed in yet');
        console.log('User has not signed in yet');
      } else {
        alert("Unable to get user's info");
        console.log("Unable to get user's info");
      }
    }
  };

  const _signIn = async () => {
    // It will prompt google Signin Widget
    try {
      await GoogleSignin.hasPlayServices({
        // Check if device has Google Play Services installed
        // Always resolves to true on iOS
        showPlayServicesUpdateDialog: true,
      });
      const userInfo = await GoogleSignin.signIn();
      console.log('User Info --> ', userInfo);
      setUserInfo(userInfo);
    } catch (error) {
      console.log('Message', JSON.stringify(error));
      if (error.code === statusCodes.SIGN_IN_CANCELLED) {
        alert('User Cancelled the Login Flow');
      } else if (error.code === statusCodes.IN_PROGRESS) {
        alert('Signing In');
      } else if (
        error.code === statusCodes.PLAY_SERVICES_NOT_AVAILABLE
      ) {
        alert('Play Services Not Available or Outdated');
      } else {
        alert(error.message);
      }
    }
  };

  const _signOut = async () => {
    setGettingLoginStatus(true);
    // Remove user session from the device.
    try {
      await GoogleSignin.revokeAccess();
      await GoogleSignin.signOut();
      // Removing user Info
      setUserInfo(null);
    } catch (error) {
      console.error(error);
    }
    setGettingLoginStatus(false);
  };
  if (gettingLoginStatus) {
    return (
      <View style={styles.container}>
        <ActivityIndicator size="large" color="#0000ff" />
      </View>
    );
  } else {
    return (


      <ScrollView showsVerticalScrollIndicator={false}
      showsHorizontalScrollIndicator={false}>

        <View style={styles.Container}>
          <View style={styles.Pcontainer}>
          {userInfo !== null ? (
              <>
              <View style={styles.headerWrapper}>


                <Image
                  style={styles.profileImage}
                  source={{ uri: userInfo.user.photo }}
                />
                
              </View>
                <Text style={styles.text2}>
                  Hello, {userInfo.user.name}!
                </Text>
                
               
              </>
            ) : (
              <GoogleSigninButton
                style={{ width: 312, height: 48 }}
                size={GoogleSigninButton.Size.Wide}
                color={GoogleSigninButton.Color.Light}
                onPress={_signIn}
              />
            )}

            <SafeAreaView>
              
            </SafeAreaView>

          </View>

          <View style={styles.container}>

            <FlatList
              data={[{ key: 1 }, { key: 2 }, { key: 3 }]}
              renderItem={this._renderItem}
              horizontal={true}
              ItemSeparatorComponent={() => <View style={{ margin: 4 }} />}
            />
          </View>
          <TouchableOpacity activeOpacity={1} style={styles.Button}

            onPress={() => navigation.navigate("Detail")}
          >
            <Image
              style={styles.tinyLogo}
              source={require('../assets/marginalia-765.png')} />
          </TouchableOpacity>
          <TouchableOpacity activeOpacity={1} style={styles.Button2}

            onPress={() => alert("test")}>
            <Image
              style={styles.tinyLogo}
              source={require('../assets/clip-1649.png')} />
          </TouchableOpacity>

          <TouchableOpacity activeOpacity={1} style={styles.Button3}

            onPress={() => alert("test")}><Image
              style={styles.tinyLogo}
              source={require('../assets/pablo-online-life.png')} /></TouchableOpacity>

          <TouchableOpacity activeOpacity={1} style={styles.Button4}

            onPress={() => alert("test")}><Image
              style={styles.tinyLogo}
              source={require('../assets/pixeltrue-time-management-1.png')} /></TouchableOpacity>

          <TouchableOpacity activeOpacity={1} style={styles.Button5}

            onPress={() => alert("test")}><Image
              style={styles.tinyLogo}
              source={require('../assets/crayon-1521.png')} /></TouchableOpacity>

          <TouchableOpacity activeOpacity={1} style={styles.Button6}

            onPress={() => alert("test")}><Image
              style={styles.tinyLogo}
              source={require('../assets/flame-787.png')} /></TouchableOpacity>

        </View></ScrollView>

    );
  }
}


function Profile({ navigation }) {
  return (
    <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
      
       <TouchableOpacity activeOpacity={1} style={styles.Button}

          onPress={() => navigation.navigate("Signup")}
          >
        <Image
          style={{
            paddingLeft:20,
            paddingTop:20,
            marginLeft: 22,
            height: 110,
            width: 100
          }}
          source={require('/Users/preethipolepalli/senizen/assets/taxi-544.png')} />
        </TouchableOpacity>
    </View>
  );
}

function Notifications({ navigation }) {
  return (
    <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
      <TouchableOpacity activeOpacity={1} style={styles.Button}

onPress={() => navigation.navigate("Signup")}
>
<Image
style={{
            paddingLeft:20,
            paddingTop:20,
            marginLeft: 22,
            height: 110,
            width: 110
          }}
source={require('/Users/preethipolepalli/senizen/assets/abstract-845.png')} />
</TouchableOpacity>

    </View>

  );
}

const Tab = createBottomTabNavigator();

export default function Dashboard() {

  return (
    <Tab.Navigator
      initialRouteName="Feed"
      tabBarOptions={{
        activeTintColor: '#e91e63',
      }}
    >
      <Tab.Screen
        name="Feed"
        component={Feed}

        options={{
          tabBarLabel: 'Home',
          tabBarIcon: ({ color, size }) => (
            <MaterialCommunityIcons name="home" color={color} size={size} />
          ),
        }}
      />

      <Tab.Screen
        name="Notifications"
        component={Notifications}
        options={{
          tabBarLabel: 'Profile',
          tabBarIcon: ({ color, size }) => (
            <MaterialCommunityIcons name="bell" color={color} size={size} />
          ),
        }}

      />

      <Tab.Screen
        name="Profile"
        component={Profile}
        options={{
          tabBarLabel: 'Settings',
          tabBarIcon: ({ color, size }) => (
            <MaterialCommunityIcons name="account" color={color} size={size} />
          ),
        }}
      />
    </Tab.Navigator>
  );
}

const styles = StyleSheet.create({
  Container: {
    flex: 1,
    paddingTop: 100,
    justifyContent: 'center',
    backgroundColor: '#F5FCFF',
    paddingBottom: 100,

  },

  Button: {
    shadowColor: '#FFE7A1',
    shadowOpacity: 1.5,
    elevation: 8,
    shadowRadius: 10,
    shadowOffset: { width: 1, height: 13 },
    marginTop: 50,
    paddingTop: 15,
    paddingBottom: 15,
    width: 150,
    height: 150,
    marginLeft: 30,
    marginRight: 30,
    backgroundColor: 'white',
    borderRadius: 20,
    borderWidth: 1,
    borderColor: '#ffbe58'
  },
  Button2: {
    shadowColor: '#FFE7A1',
    shadowOpacity: 1.5,
    elevation: 8,
    shadowRadius: 10,
    shadowOffset: { width: 1, height: 13 },
    marginTop: -150,
    paddingTop: 15,
    paddingBottom: 15,
    width: 150,
    height: 150,
    marginLeft: 220,
    marginRight: 30,
    backgroundColor: 'white',
    borderRadius: 20,
    borderWidth: 1,
    borderColor: '#ffbe58'
  },
  Button3: {
    shadowColor: '#FFE7A1',
    shadowOpacity: 1.5,
    elevation: 8,
    shadowRadius: 10,
    shadowOffset: { width: 1, height: 13 },
    marginTop: -150,
    paddingTop: 15,
    paddingBottom: 15,
    width: 150,
    height: 150,
    marginTop: 40,
    marginLeft: 30,
    marginRight: 30,
    backgroundColor: 'white',
    borderRadius: 20,
    borderWidth: 1,
    borderColor: '#ffbe58'
  },

  Button4: {
    shadowColor: '#FFE7A1',
    shadowOpacity: 1.5,
    elevation: 8,
    shadowRadius: 10,
    shadowOffset: { width: 1, height: 13 },
    marginTop: -150,
    paddingTop: 15,
    paddingBottom: 15,
    width: 150,
    height: 150,
    marginLeft: 220,
    marginRight: 30,
    backgroundColor: 'white',
    borderRadius: 20,
    borderWidth: 1,
    borderColor: '#ffbe58'
  },
  Button5: {
    shadowColor: '#FFE7A1',
    shadowOpacity: 1.5,
    elevation: 8,
    shadowRadius: 10,
    shadowOffset: { width: 1, height: 13 }, marginTop: -150,
    paddingTop: 15,
    paddingBottom: 15,
    width: 150,
    height: 150,
    marginLeft: 30,
    marginTop: 30,
    marginRight: 30,
    backgroundColor: 'white',
    borderRadius: 20,
    borderWidth: 1,
    borderColor: '#ffbe58'
  },
  Button6: {
    shadowColor: '#FFE7A1',
    shadowOpacity: 1,
    elevation: 8,
    shadowRadius: 10,
    shadowOffset: { width: 1.3, height: 10 },
    marginTop: -150,
    paddingTop: 15,
    paddingBottom: 15,
    width: 150,
    height: 150,
    marginLeft: 220,
    marginRight: 30,
    backgroundColor: 'white',
    borderRadius: 20,
    borderWidth: 1,
    borderColor: '#ffbe58'

  },


  TextStyle: {
    color: '#fff',
    textAlign: 'center',
  },
  tinyLogo: {
    marginTop: 20,

    marginLeft: 3,

    width: 150,
    height: 100,
  },
  wrapper: {
    paddingTop: 80,
    marginTop: -100,
    height: 300
  },
  slide1: {
    height: 200,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#9DD6EB',

  },
  slide2: {
    height: 200,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#97CAE5'
  },
  slide3: {
    height: 200,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#92BBD9'
  },
  text: {
    color: '#fff',
    fontSize: 30,
    fontWeight: 'bold'
  },
  text2: {
    color: 'black',
    fontSize: 25,
    fontWeight: 'bold',
    paddingLeft: 65,

  },
  discoverItem: {
    width: 170,
    height: 250,
    justifyContent: 'flex-end',
    paddingHorizontal: 10,
    paddingVertical: 15,
    marginRight: 20,
  },
  discoverItemImage: {
    borderRadius: 20,
  },
  discoverItemTitle: {
    fontFamily: 'Lato-Bold',
    fontSize: 18,
    color: colors.white,
  },
  Pcontainer: {
    flex: 1,
  },
  headerWrapper: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    paddingTop: -30,
    marginBottom: 40,
    alignItems: 'center',
  },
  profileImage: {
    width: 60,
    height: 60,
    borderRadius: 40,
  },
  categorySelectWrapper: {
    alignSelf: 'center',
    justifyContent: 'center',
    marginTop: 20,
    width: 26,
    height: 26,
    borderRadius: 26,
    marginBottom: 20,
  },
})