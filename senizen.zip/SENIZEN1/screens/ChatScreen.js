import React, { useState, useEffect } from 'react';
import RNKommunicateChat from 'react-native-kommunicate-chat';

export default function ChatScreen() {
RNKommunicateChat.openConversation((response, message) => {
    if(response == 'Error') {
      console.log(message);
    } else {
      //chat screen launched successfully
    }
  });

  let clientChannelKey = "clientChannelKey" //pass the clientChannelKey here
let takeOrder = true //skip chat screen on back press, pass false if you want to show chat screen on back press
      
RNKommunicateChat.openParticularConversation(clientChannelKey, takeOrder, (response, responseMessage) => {
        if(response == 'Error') {
          console.log(message);
        } else {
          //conversation launched successfully
        }
      });

      let conversationObject = {
        'isSingleConversation' : true //passing true will start the same conversation everytime
       };
  
    RNKommunicateChat.buildConversation(conversationObject, (response, responseMessage) => {
          if(response == "Success") {
              console.log("Kommunicate create conversation successful the clientChannelKey is : " + responseMessage);
          } else {
              console.log("Kommunicate create conversation failed : " + responseMessage);
          }
        });   

        var conversationObject = {
            'isSingleConversation' : false,
            'agentIds':['shayna.vinoth2007@gmail.com'],  //List of agentIds. AGENT_ID is the emailID used to signup on Kommunicate
            'botIds': ['senizen-bot-hiyyu']  //List of botIds. Go to Manage Bots(https://dashboard.kommunicate.io/bots/manage-bots) -> Copy botID
             };
             
       RNKommunicateChat.buildConversation(conversationObject, (response, responseMessage) => {
              if(response == "Success") {
                  console.log("Kommunicate create conversation successful the clientChannelKey is : " + responseMessage);
              } else {
                  console.log("Kommunicate create conversation failed : " + responseMessage);
              }
            });  }
            